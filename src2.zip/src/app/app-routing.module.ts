import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { TableComponent } from './table/table.component';
import { EditComponent } from './edit/edit.component';
import { ApiRegisterComponent } from './api-register/api-register.component';
import { ApiLoginComponent } from './api-login/api-login.component';
import {ApiTableComponent} from './api-table/api-table.component';
import { ApiEditComponent } from './api-edit/api-edit.component';

const routes: Routes = [  
             {path: '', component:LoginComponent},
             {path: 'login', component: LoginComponent},
             {path: 'register', component: RegisterComponent},
             {path: 'table',component: TableComponent},
             {path: 'edit',component: EditComponent},
             {path: 'api-register',component: ApiRegisterComponent },
             {path: 'api-login',component: ApiLoginComponent },
             {path: 'api-table',component:ApiTableComponent},
             {path: 'api-edit',component:ApiEditComponent},

//{ path: '/login',   redirectTo: '/register', pathMatch: 'full' }
          ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
