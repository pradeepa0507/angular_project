import { Component } from '@angular/core';

@Component({
  selector: 'app-api-edit',
  templateUrl: './api-edit.component.html',
  styleUrls: ['./api-edit.component.css']
})
export class ApiEditComponent {
  username:any;
  email:any;
  password:any;
update(){}
}
