import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-api-table',
  templateUrl: './api-table.component.html',
  styleUrls: ['./api-table.component.css']
})
export class ApiTableComponent {
  users: any;
 
  constructor(private serverService: ServicesService,private router: Router) {
  }
  ngOnInit() {
    this.table_data();

  }
  table_data(){
    var api_req:any = new Object();
    var agents_req:any = new Object();
    agents_req.action="list";
    api_req.operation="ang";
    api_req.moduleType="ang";
    api_req.api_type="web"; 
    api_req.element_data = agents_req;
    console.log(api_req);
    this.serverService.sendServer(api_req).subscribe((response:any) => {
      console.log(response.result.data);
      if(response.status==true){
        this.users = response.result.data;
        console.log(this.users);
      }
    },
    (error)=>{
        console.log(error);
    });
  }
  edit(_id:any){
    var api_req:any = new Object();
    var agents_req:any = new Object();
    agents_req.action="edit";
    agents_req.id=_id;
    api_req.operation="ang";
    api_req.moduleType="ang";
    api_req.api_type="web"; 
    api_req.element_data = agents_req;
    console.log(api_req);
    this.serverService.sendServer(api_req).subscribe((response:any) => {
      console.log(response.result.data);
      if(response.status==true){
        var link =this.router.navigate(['/api-edit'])

        this.users = response.result.data;
      //  var link =this.router.navigate(['/api-edit'])

        console.log(this.users);
      }
    },
    (error)=>{
        console.log(error);
    });
  }
  delete(id:any){
    var api_req:any = new Object();
    var agents_req:any = new Object();
    agents_req.action="delete";
    agents_req.id=id;
    api_req.operation="ang";
    api_req.moduleType="ang";
    api_req.api_type="web"; 
    api_req.element_data = agents_req;
    console.log(api_req);
    this.serverService.sendServer(api_req).subscribe((response:any) => {
      console.log(response.result.data);
      if(response.result.data==1){
        this.users = response.result.data;
        this.table_data();
        console.log(this.users);
      }
    },
    (error)=>{
        console.log(error);
    });
  }
}
